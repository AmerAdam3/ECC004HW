﻿Public Class Form1
    ' Define arrays for names and marks
    Dim Names(9) As String
    Dim Marks(9) As Integer
    Dim StCount As Integer = 0 ' Keeps track of the number of students

    ' Bubble Sort in ascending order
    Private Sub BubbleSortAscending()
        For i As Integer = 0 To StCount - 2
            For j As Integer = 0 To StCount - 2 - i
                If Marks(j) > Marks(j + 1) Then
                    Swap(j, j + 1)
                End If
            Next
        Next
    End Sub

    ' Bubble Sort in descending order
    Private Sub BubbleSortDescending()
        For i As Integer = 0 To StCount - 2
            For j As Integer = 0 To StCount - 2 - i
                If Marks(j) < Marks(j + 1) Then
                    Swap(j, j + 1)
                End If
            Next
        Next
    End Sub

    ' Swap elements in Marks and Names arrays
    Private Sub Swap(ByVal index1 As Integer, ByVal index2 As Integer)
        Dim tempMark As Integer = Marks(index1)
        Marks(index1) = Marks(index2)
        Marks(index2) = tempMark

        Dim tempName As String = Names(index1)
        Names(index1) = Names(index2)
        Names(index2) = tempName
    End Sub

    ' Button to add a student's name and mark
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Read name and mark, and store them in the next empty slot
        Names(StCount) = InputBox("Enter the name of the student")
        Marks(StCount) = CInt(InputBox("Enter the mark of the student"))

        ' Display the new name and mark in the DataGridView
        DataGridView1.Rows.Add(Names(StCount), Marks(StCount))

        ' Increment counter for the next slot
        StCount += 1
    End Sub

    ' Button to find the maximum mark using Bubble Sort
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        BubbleSortDescending()
        MsgBox("Student " & Names(0) & " has the maximum mark: " & Marks(0))
        UpdateDataGridView()
    End Sub

    ' Button to find the minimum mark using Bubble Sort
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        BubbleSortAscending()
        MsgBox("Student " & Names(0) & " has the minimum mark: " & Marks(0))
        UpdateDataGridView()
    End Sub

    ' Update the DataGridView to reflect the sorted arrays
    Private Sub UpdateDataGridView()
        ' Clear existing rows in DataGridView
        DataGridView1.Rows.Clear()

        ' Add the sorted data back into the DataGridView
        For i As Integer = 0 To StCount - 1
            DataGridView1.Rows.Add(Names(i), Marks(i))
        Next
    End Sub

    ' Form Load event: Add columns to the DataGridView
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Add columns to the DataGridView if not already added
        If DataGridView1.Columns.Count = 0 Then
            DataGridView1.Columns.Add("NameColumn", "Name") ' Column for student names
            DataGridView1.Columns.Add("MarkColumn", "Mark") ' Column for student marks
        End If
    End Sub
End Class
